"""Chain for chatting with a vector database."""
